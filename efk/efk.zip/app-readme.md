# EFK

EFK(Elasticsearch + Filebeat + Kibana) are flexible and powerful open source projects, provides distributed real-time search and analytics tools.</br>

This chart bootstraps a EFK stack with the following components:
- Elasticsearch
- Kibana
- Filebeat
- Metricbeat

**Warning:** upgrade from previous version under v7.3.0 is not supported, please re-deploy a new EFK app if you want to use the new v7.3.0 version.
